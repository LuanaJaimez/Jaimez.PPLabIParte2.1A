#ifndef SERVICIO_H_INCLUDED
#define SERVICIO_H_INCLUDED

typedef struct
{
    int id;
    char descripcion[25];
    int precio;

}eServicio;

#endif // SERVICIO_H_INCLUDED


void mostrarServicios(eServicio vec[], int tam);
int cargarDescripcionServicio(char descripcion[], int id, eServicio servicios[], int tam);
