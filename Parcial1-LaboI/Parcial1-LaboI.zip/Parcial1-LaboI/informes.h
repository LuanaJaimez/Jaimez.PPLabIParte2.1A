#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED



#endif // INFORMES_H_INCLUDED

int menuInformes();
void informar(eAuto autos[], int tam, eCliente clientes[], int tamCl, eColor colores[], int tamC, eMarca marcas[], int tamM);
void informarAutosColor(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl);
void informarAutosPorMarcaS(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl);
void informarAutosPorMarca(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl);
void informarAutoMasViejo(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl);
void informarAutosPorColorYMarca(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl);
