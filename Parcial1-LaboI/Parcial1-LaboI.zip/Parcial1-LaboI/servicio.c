#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "auto.h"
#include "trabajo.h"
#include "servicio.h"



void mostrarServicios(eServicio vec[], int tam)
{
    printf("***** Listado de Servicios *****\n");
    printf(" ID Servicio   Descripcion   Precio  \n\n");
    for(int i=0; i<tam; i++)
    {
        printf("  %d        %10s      %d  \n", vec[i].id, vec[i].descripcion, vec[i].precio);
    }
}

//---------------------------------------------------------------------------------------------------

int cargarDescripcionServicio(char descripcion[], int id, eServicio servicios[], int tam)
{
    int todoOk = 0;

    for(int i=0; i<tam; i++)
    {
        if(servicios[i].id == id)
        {
            strcpy(descripcion, servicios[i].descripcion);
            todoOk = 1;
        }
    }
    return todoOk;
}
