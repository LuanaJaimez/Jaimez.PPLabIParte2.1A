#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "utn.h"
#include "auto.h"
#include "informes.h"


int menuInformes()
{
    int opcion;

    system("cls");
    printf("***** Informes autos *****\n\n");
    printf("1. Mostrar autos de un color seleccionado\n");
    printf("2. Mostrar autos de una marca seleccionado\n");
    printf("3. Mostrar auto mas viejo\n");
    printf("4. Mostrar autos por marca\n");
    printf("5. Mostrar autos por marca y color seleccionados\n");
    printf("6. Salir\n");
    printf("\nElija una opcion: ");
    fflush(stdin);
    scanf("%d", &opcion);

    return opcion;
}

//---------------------------------------------------------------------------------------------------

void informar(eAuto autos[], int tam, eCliente clientes[], int tamCl, eColor colores[], int tamC, eMarca marcas[], int tamM)
{
    char seguir = 's';
    char confirma;

    do{
        switch(menuInformes())
        {
        case 1:
            informarAutosColor(autos, tam, colores, tamC, marcas, tamM, clientes, tamCl);
            break;
        case 2:
            informarAutosPorMarcaS(autos, tam, colores, tamC, marcas, tamM, clientes, tamCl);
            break;
        case 3:
            informarAutoMasViejo(autos, tam, colores, tamC, marcas, tamM, clientes, tamCl);
            break;
        case 4:
            informarAutosPorMarca(autos, tam, colores, tamC, marcas, tamM, clientes, tamCl);
            break;
        case 5:
            informarAutosPorColorYMarca(autos, tam, colores, tamC, marcas, tamM, clientes, tamCl);
            break;
        case 6:
            printf("Confirme salida (s/n): ");
            fflush(stdin);
            scanf("%c", &confirma);
            if(confirma == 's')
            {
                seguir = 'n';
            }
            break;
        }

        system("pause");

    }while(seguir == 's');

}

//---------------------------------------------------------------------------------------------------

void informarAutosColor(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl)
{
    int flag;
    int auxColor;

    system("cls");
    printf("***** Autos por color especifico *****\n\n");

    mostrarColores(colores, tamC);
	utn_getEntero(&auxColor, 3, "Ingrese el ID del color de los autos a listar: ", "Error, no es un color", 5000, 5004);

	printf("  Id      Patente    ID Marca      Marca       ID Color       Color       Modelo     Cliente\n\n");

	for(int i = 0 ; i < tam; i++)
	{
		if(autos[i].isEmpty == 0 && autos[i].idColor == auxColor)
		{
			mostrarAuto(autos[i], marcas, tamM, colores, tamC, clientes, tamCl);
			flag = 1;
		}
	}
	if(flag == 0)
	{
		printf("\nNo hay autos con ese color\n\n");
	}

}

//---------------------------------------------------------------------------------------------------

void informarAutosPorMarcaS(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl)
{
	int flag = 0;
	int auxMarca;

	system("cls");
	printf("***** Autos por marca especifica *****\n\n");

	mostrarMarcas(marcas, tamM);
	utn_getEntero(&auxMarca, 3, "Ingrese el id de la marca del auto a listar: ", "Error, no es una marca", 1000, 1004);

	//printf("ID    Modelo    Marca    Tipo     Precio\n\n");

	for(int i = 0 ; i < tam; i++)
	{
		if(autos[i].isEmpty == 0 && autos[i].idMarca == auxMarca)
		{
			mostrarAuto(autos[i], marcas, tamM, colores, tamC, clientes, tamCl);
			flag = 1;
		}
	}
	if(flag == 0)
	{
		printf("No existen autos con esa marca para listar.\n\n");
	}

}

//---------------------------------------------------------------------------------------------------

void informarAutoMasViejo(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl)
{
    eAuto mayorAuto;
    int flag = 0;

    printf("***** Auto/s mas viejo *****\n\n");

    for(int i=0; i<tam; i++)
    {
        if(autos[i].modelo < mayorAuto.modelo || flag == 0)
        {
            mostrarAuto(autos[i], marcas, tamM, colores, tamC, clientes, tamCl);
            mayorAuto = autos[i];
            flag = 1;
        }
    }
}

//---------------------------------------------------------------------------------------------------

void informarAutosPorMarca(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl)
{
    int flag;

    system("cls");
    printf("***** Autos por marca *****\n\n");

    for(int i=0; i<tamM; i++)
    {
        flag = 0;
        printf("Marca: %s\n", marcas[i].descripcion);
        printf(" ---------\n\n");


        //recorro los empleados buscando aquellos del sector donde estoy parado
        for(int j=0; j<tam; j++)
        {
            if(autos[j].isEmpty == 0 && autos[j].idMarca == marcas[i].id)
            {
                mostrarAuto(autos[i], marcas, tamM, colores, tamC, clientes, tamCl);
                flag = 1;
            }
        }
        if(flag == 0)
        {
            printf("\nNo hay autos registrados con esta marca\n");
        }
        printf("\n--------------------------------------------------------------\n");
    }

}

//---------------------------------------------------------------------------------------------------

void informarAutosPorColorYMarca(eAuto autos[], int tam, eColor colores[], int tamC, eMarca marcas[], int tamM, eCliente clientes[], int tamCl)
{
	int flag = 0;
	int auxMarca;
	int auxColor;
    int contadorMarcaColor = 0;
    char confirma;

	system("cls");
	printf("***** Autos por marca especifica *****\n\n");

	mostrarMarcas(marcas, tamM);
	utn_getEntero(&auxMarca, 3, "Ingrese Id Marca (1000-1004): ", "Error, no es una marca: \n", 1000, 1004);
	mostrarColores(colores, tamC);
	utn_getEntero(&auxColor, 3, "Ingrese Id Color (5000-5004): ", "Error, no es un color: \n", 5000, 5004);


	for(int i = 0 ; i < tam; i++)
	{
		if(autos[i].isEmpty == 0 && autos[i].idMarca == auxMarca && autos[i].idColor == auxColor)
		{
			contadorMarcaColor++;
			flag = 1;
		}
	}
	if(flag == 1)
    {
        printf("La cantidad de autos de la marca y el color elegido es: %d\n\n", contadorMarcaColor);

        printf("Mostrar auto de la marca y el color seleccionado (s/n): ");
        fflush(stdin);
        scanf("%c", &confirma);
        if(confirma == 's')
        {
            for(int i = 0 ; i < tam; i++)
            {
                if(autos[i].isEmpty == 0 && autos[i].idMarca == auxMarca && autos[i].idColor == auxColor)
                {
                    mostrarAuto(autos[i], marcas, tamM, colores, tamC, clientes, tamCl);
                }
            }
        }
        else if(confirma == 'n')
        {
            printf("Se ha cancelado la operacion\n\n");
        }


    }
	else if(flag == 0)
	{
		printf("\nNo existen autos con esa marca y ese color para listar.\n\n");
	}

}
