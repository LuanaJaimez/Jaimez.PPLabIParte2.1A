#include "auto.h"
#include "servicio.h"
#ifndef TRABAJO_H_INCLUDED
#define TRABAJO_H_INCLUDED

typedef struct
{
    int id;
    char patente[20];
    int idServicio;
    eFecha fecha;
    int isEmpty;

}eTrabajo;

#endif // TRABAJO_H_INCLUDED


int buscarLibreT(eTrabajo vec[], int tam);
int altaTrabajo(int idx, eTrabajo vec[], int tam, eServicio lavados[], int tamSer, eAuto autos[], int tamAu, eMarca marca[], int tamM, eColor color[], int tamC, eCliente clientes[], int tamCl);
void mostrarTrabajo(eTrabajo x, eServicio servicios[], int tamS);
void mostrarTrabajos(eTrabajo vec[], int tam, eServicio servicios[], int tamS);
